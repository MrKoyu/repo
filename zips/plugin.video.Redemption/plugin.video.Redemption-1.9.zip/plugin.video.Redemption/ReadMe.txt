--Key--
* Insert addon name lowercase no spaces
Step by Step
1 Change Name of folder from plugin.video.oka to plugin.video.*
2 Change Settings in _Edit.py